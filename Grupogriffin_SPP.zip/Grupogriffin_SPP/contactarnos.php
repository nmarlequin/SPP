<?php include('includes/header.php'); ?>
<body>
<h1 style="text-align: center; font-family: Arial black;">Contactos:</h1>
    
</body>
<?php include('includes/footer.php'); ?>