<?php include('includes/header.php'); ?>
<h3 style="text-align: center; font-family: Arial black;" class="text-light mt-2">¿Quiénes somos?</h3>
<body>
    <div class="bg-light p-4">
    <p style="font-size: medium;">En Grupo Griffin, es un honor para nosotros servir como su principal proveedor de soluciones tecnológicas confiables. 
Nos especializamos en la comercialización de productos que abarcan desde equipos informáticos hasta hardware de vanguardia, así como 
periféricos de alto rendimiento y sistemas de imagen y sonido de primera categoría. Guiados por una profunda dedicación hacia la tecnología y un 
compromiso sólido con la excelencia en la satisfacción del cliente, nos esmeramos en ofrecerle las soluciones más avanzadas del mercado a tarifas competitivas.
<br>
<br>
Nuestro surtido abarca una amplia variedad de productos, desde robustas estaciones de trabajo y dispositivos portátiles de computación hasta componentes de 
hardware como tarjetas gráficas, procesadores y unidades de almacenamiento. Además, ofrecemos una selección de periféricos diseñados para mejorar la experiencia 
del usuario, incluyendo teclados, ratones, monitores de alta resolución y otros dispositivos. Para aquellos con un interés particular en la calidad de imagen y 
sonido, disponemos de una excepcional gama de televisores, sistemas de sonido envolvente, auriculares y cámaras para satisfacer todas las necesidades audiovisuales.
<br>
<br>
La distinción fundamental de Grupos Griffin radica en nuestro firme compromiso con la excelencia y la calidad en la prestación de servicios. Nos dedicamos 
estrechamente a colaborar con los principales fabricantes de tecnología con el fin de garantizar que nuestros clientes adquieran productos de primera categoría 
respaldados por garantías sólidas. Nuestro equipo de especialistas en tecnología permanece siempre a disposición para ofrecer orientación y recomendaciones a medida, 
garantizando así que encuentren la solución óptima para sus requerimientos particulares.
<br>
<br>
Explore nuestro sitio web para descubrir nuestro amplio catálogo de productos y servicios. 
<br>
Aquí su satisfacción es nuestra prioridad número uno. ¡Esperamos contar con su confianza y servirle en su búsqueda de las mejores soluciones tecnológicas!</p>
</p>
    </div>

<br>
<h3 style="text-align: center; font-family: Arial black;" class="text-light">Personal</h3>

<div class="album p-1  bg-body-tertiary">
    <div class="container">
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">

<div class="col">
          <div class="card shadow-sm">
          <img src="assets/img/52.jpg" class="img-thumbnail" alt="Personal">
            <div class="card-body">
            <p style="text-align: Rigth; font-family: Arial black;">Joaquín Vásquez:</p>
        <p>Gerente</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                </div>
              </div>
            </div>
          </div>
        </div>
        
      <div class="col">
          <div class="card shadow-sm">
          <img src="assets/img/53.png" class="img-thumbnail" alt="Personal">
            <div class="card-body">
            <p style="text-align: Rigth; font-family: Arial black;">Benjamín Rosales:</p>
        <p>Empleado</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img src="assets/img/54.png" class="img-thumbnail" alt="Personal">
            <div class="card-body">
            <p style="text-align: Rigth; font-family: Arial black;">Camilo Díaz:</p>
        <p>Empleado</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img src="assets/img/55.png" class="img-thumbnail" alt="Personal">
            <div class="card-body">
            <p style="text-align: Rigth; font-family: Arial black;">Valentina Gómez:</p>
        <p>Atención al cliente</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                </div>
              </div>
            </div>
          </div>
        </div>




      </div>
    </div>
  </div>
</body>
<?php include('includes/footer.php'); ?>