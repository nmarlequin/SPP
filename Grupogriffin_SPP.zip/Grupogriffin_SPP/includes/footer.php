<div class="container">
  <footer class="py-5">
    <div class="row">
      <div style="display: flex; justify-content: center; align-items: center; height: 200px;">
    <p class="text-light">&copy; Grupo Griffin  El Salvador . Todos los derechos reservados.</p>
    </div>
      </footer>
</div>
</html>