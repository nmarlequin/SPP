<?php include('includes/header.php'); ?>
<h3 style="text-align: center; font-family: Arial black;" class="text-light mt-2">Ubicación</h3>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 text-Dark">
            <div class="bg-light p-4">
            <p style="text-align: Rigth; font-family: Arial black;">Nos encontramos en:</p>
        <p>Nos encontramos ubiado en la zona occidental de Bogotá en Multiplaza en Carretera Panamericana, Antiguo Cuscatlán, Justo en la Primera planta junto a la area de comidas junto a Panaderia San Martin.</p>
         <br>
    <p style="text-align: Rigth; font-family: Arial black;">Horarios:</p>
     Lunes a viernes de 8:30 AM a 6:00 PM y Domingo de 9:00 am a 3:00 PM
    </p>
 </div>


        </div>
        <div class="col-md-8">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.644056908355!2d-89.2487455!3d13.6793947!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f632e2afad31d7d%3A0x40f719aa05749a78!2sMultiplaza!5e0!3m2!1ses-419!2ssv!4v1696526552900!5m2!1ses-419!2ssv" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</div>
</body>
<?php include('includes/footer.php'); ?>

